# tripodhub

This package contains the 10 experiments listed in the PESIT Machine Learning Lab manual and is set up to work well in Jupyter Notebook.

## Included labs

1. Histogram, box plot, and outlier analysis on California Housing
2. Correlation matrix, heatmap, and pair plot on California Housing
3. PCA on Iris dataset
4. Find-S algorithm using CSV training data
5. KNN classification on generated points
6. Locally Weighted Regression
7. Linear and Polynomial Regression
8. Decision Tree classification on Breast Cancer data
9. Naive Bayes on Olivetti Faces
10. K-means clustering on Breast Cancer data

## Install locally

```powershell
python -m pip install -e .
```

## Run in Jupyter Notebook

```python
from tripodhub import lab1, lab4, run_lab

run_lab(1, show_plots=True)
lab4.run()
```

## Run from terminal

```powershell
ml-lab --list
ml-lab 1 --no-plots
ml-lab 4 --csv-path training.csv
```

## Build distribution files

```powershell
python -m build
```

## Notes

- `lab07` uses California Housing as a practical replacement for the deprecated Boston dataset loader.
- `lab09` and the Auto MPG fallback in `lab07` may download datasets the first time they are run.
