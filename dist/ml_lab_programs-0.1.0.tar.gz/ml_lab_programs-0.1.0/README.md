# ML Lab Programs

This package contains the 10 experiments listed in the PESIT Machine Learning Lab manual.

## Included labs

1. Histogram, box plot, and outlier analysis on California Housing
2. Correlation matrix, heatmap, and pair plot on California Housing
3. PCA on Iris dataset
4. Find-S algorithm using CSV training data
5. KNN classification on generated points
6. Locally Weighted Regression
7. Linear and Polynomial Regression
8. Decision Tree classification on Breast Cancer data
9. Naive Bayes on Olivetti Faces
10. K-means clustering on Breast Cancer data

## Install locally

```powershell
python -m pip install -e .
```

## Run from Python

```python
from ml_lab_programs import lab01, lab04

print(lab01.run(show_plots=False))
print(lab04.run())
```

## Run from terminal

```powershell
ml-lab --list
ml-lab lab01 --no-plots
ml-lab lab04 --csv-path training.csv
```

## Build distribution files

```powershell
python -m build
```

## Notes

- `lab07` uses California Housing as a practical replacement for the deprecated Boston dataset loader.
- `lab09` and the Auto MPG fallback in `lab07` may download datasets the first time they are run.
